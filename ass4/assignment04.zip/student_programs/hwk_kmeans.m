% CSI 5325 -- Machine Learning
% Assignment 4
% Prof. Greg Hamerly, Baylor University
%
% Implements the k-means algorithm. Your code should initialize the centers, and
% then perform the k-means updates (assign points to centers, move centroids)
% until convergence.
%
% Parameters:
%   X: the m*n matrix of m examples having n features each
%   k: the number of clusters
%
% Return values:
%   clusters: the m*1 vector of which cluster each example has gone to
%   centroids: the k*n matrix indicating the positions of the k centroids
function [clusters, centroids] = hwk_kmeans(X, k)

    % YOUR CODE HERE

    
